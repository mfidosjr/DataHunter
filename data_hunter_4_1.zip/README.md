# Data Hunter 4.1 🔎

Aplicativo Streamlit para busca e análise automática de datasets públicos.

- Busca automática
- Download múltiplo (.csv, .xlsx, .json, .zip)
- Análise de qualidade
- Ranking de datasets
- Gráficos interativos